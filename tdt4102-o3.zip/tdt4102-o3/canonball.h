#pragma once

double acclY();
double velY(double initVelocityY, double time);
double posY(double initPosition, double initVelocity, double time);
double posX();
void printTime(double time);
double flightTime(double initVelocityY);

double getUserInputTheta();
double getUserInputAbsVelocity();
double degToRad(double deg);
double getVelocityX(double theta, double absVelocity);
double getVelocityY(double theta, double absVelocity);
vector<double> getVelocityVector(double theta, double absVelocity);

//double getDistanceTraveled(double velocityX, double velocityY);