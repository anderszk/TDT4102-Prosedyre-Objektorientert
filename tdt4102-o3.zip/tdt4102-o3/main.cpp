//
// This is example code from Chapter 2.2 "The classic first program" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
// 
// keep_window_open() added for TDT4102, excercise 0


#include "std_lib_facilities.h"
#include "canonball.h"


//------------------------------------------------------------------------------'

int main()
{
	cout << "Hello, World!\n";
}

//------------------------------------------------------------------------------
