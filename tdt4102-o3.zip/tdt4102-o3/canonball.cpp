#include "std_lib_facilities.h"
#include "canonball.h"
#include <math.h>
#include <cmath>

//------------------------------------------------------------------------------------------------------------

double acclY(){
    return -9.81;
}

double velY(double initVelocityY, double time){
    return initVelocityY + acclY()*time;
}

double posY(double initPosition, double initVelocity, double time){
    double koko = (acclY()*pow(time, 2.0));
    return initPosition + initVelocity*time + koko/2.0;
}

double posX(double initPosition, double initVelocity, double time){
    return initPosition + initVelocity*time;
}

void printTime(double time){
    double hours = time/3600;
    double minutes = (time/60) - (60*hours);
    cout << hours << ':' << minutes << ':' << int(time)%60; 
}

double flightTime(double initVelocityY){
    return (-2*initVelocityY)/acclY();
}

double getUserInputTheta(){
    int angle;
    cout << "Enter an angle here: ";
    cin >> angle;
    return angle;
}

double getUserInputAbsVelocity(){
    int vel;
    cout << "Input the absolute velocity here: ";
    cin >> vel;
    return vel;
}

double degToRad(double deg){
    return (deg*3.14159265358979)/180;
}

double getVelocityX(double theta, double absVelocity){
    return absVelocity*cos(theta);
}

double getVelocityY(double theta, double absVelocity){
    return absVelocity*sin(theta);
}
vector<double> getVelocityVector(double theta, double absVelocity){
    vector<double> returnThis;
    returnThis.push_back(getVelocityX(theta, absVelocity));
    returnThis.push_back(getVelocityY(theta, absVelocity));
    return returnThis;
}

void testDeviation(double compareOperand, double toOperand,
double maxError, string name){
    cout << compareOperand << ":" << toOperand << ":" << maxError << ":" << name;
}


//