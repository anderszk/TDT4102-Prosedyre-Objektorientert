#include "std_lib_facilities.h"
#include "oppg1.h"
#include "oppg2.h"
#include "oppg3.h"


//------------------------------------------------------------------------------'

double discriminant(double a, double b, double c){
    return (b*b)-(4*a*c);
}


void findRealRoots(double a, double b, double c){
    int x1;
    int x2;

    if (discriminant(a,b,c) > 0){
        cout << "Found 2 valid roots: ";
        x1 = ((-b)+sqrt(discriminant(a,b,c))/2*a);
        x2 = ((-b)-sqrt(discriminant(a,b,c))/2*a);
        cout << "x1 = " << x1 << " x2 = " << x2;
        
    }
    else if (discriminant(a,b,c) == 0){
        x1 = ((-b)+sqrt(discriminant(a,b,c))/2*a);
        cout << "Found 1 valid root:";
        cout << "x1 = x2 = " << x1;

    }
    else if (discriminant(a,b,c) < 0){
        cout << "Found 0 valid roots";
    }
}

void solveQuadraticEquation(){
    int a = 0;
    int b = 0;
    int c = 0;
    cout << "Enter a in ax^2+xb+c: ";
    cin >> a;
    cout << "Enter b in ax^2+xb+c: ";
    cin >> b;
    cout << "Enter b in ax^2+xb+c: ";
    cin >> c;
    findRealRoots(a,b,c);
}


void menu(){
    int choice = 0;
    cout << "0) Avslutt \n 1) Summer to tall \n 2) Summer flere tall \n 3) Konverter NOK til EURO. \n 4) Finne røtter til andregradslikning";
    cout << "Angi valg (0-3)";
    cin >> choice;
    if (choice == 0){
        return;
    }
    else if (choice == 1){
        inputIntegersAndPrintSum();
        menu();
    }
    else if (choice == 2){
        sumInput();
        menu();
    }
    else if (choice == 3){
        converter();
        menu();
    }
    else if (choice == 4){
        solveQuadraticEquation();
        menu();
    }
    else{
        cout << "Invalid choice, please choose again :)";
        menu();
    }

}