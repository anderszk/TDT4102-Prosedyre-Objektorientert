#pragma once

int heisann;



void inputAndPrintInteger();

int inputInteger();

int inputIntegersAndPrintSum();

bool isOdd();

void printHumanReadableTime(int sec);