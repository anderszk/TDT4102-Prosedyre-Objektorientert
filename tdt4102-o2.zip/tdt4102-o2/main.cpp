#include "std_lib_facilities.h"
#include "Graph.h"
#include "AnimationWindow.h"
#include "oppg1.h"
#include "oppg2.h"
#include "oppg3.h"
#include "oppg5.h"
#include "oppg6.h"

int main()
{
	//inputAndPrintInteger();


	//int oppg2 = inputInteger();
	//cout << "Du skrev tallet: " << oppg2;

	//int c = inputIntegersAndPrintSum();
	//cout << "Summen av tallene du skrev inn var: " << c;

	//cout << "Oppgave 1d): Man må bruke inputinteger for å kunne beholde inputen til brukeren, dette er fordi den andre funksjonen ikke returnerer en verdi."

	cout << heisann;
	//bool odd = isOdd();
	//if (odd){
	//	cout << "your number was odd";
	//}
	//else{
	//	cout << "Your number was even";
	//}

	//cout << "Oppgave 1f):"
	//printHumanReadableTime(34874);

	triangle();

	//cout << summerCancel();

	// 6c, sikkert glemt å inkludere et bibliotek ;)
	// 6d, Fikk ingen feilmeldinger, men ser ut som at for løkken itererer 10 ganger og at det kun er 9 elementer i vektoren


}

//------------------------------------------------------------------------------
