#include "std_lib_facilities.h"
#include "oppg1.h"

//------------------------------------------------------------------------------'

void inputAndPrintInteger(){
	int x = 0;

	cout << "Skriv inn et heltall her: ";
	cin >> x;
	cout << "Tallet du skrev inn var: " << x;
}

int inputInteger(){
	int integer = 0;
	cout << "Skriv inn et heltall her: ";
	cin >> integer;
	return integer;
}

int inputIntegersAndPrintSum(){
	int a = inputInteger();
	int b = inputInteger();
	return a+b;
}

bool isOdd(){
	//int check = inputInteger();
	return  0; //(check % 2 = 1);
}

void printHumanReadableTime(int sec){
    int hours = sec/3600;
    int minutes = (sec/60) - (60*hours);
    cout << hours << ':' << minutes << ':' << sec%60; 
}