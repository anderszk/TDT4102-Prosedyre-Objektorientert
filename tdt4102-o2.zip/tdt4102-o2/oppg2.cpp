#include "std_lib_facilities.h"
#include "oppg2.h"


//------------------------------------------------------------------------------'

int heisann = 10;

int sumInput(){
    int count = 0;
    int summer = 0;
    int current = 0;

    cout << "Hvor mange tall vil du summere";
    cin >> count;

    for (int i = 0; i < count; i++){
        cout << "Enter number here: ";
        cin >> current;
        summer += current;
    }
     return summer;
}

int summerCancel(){
    int holder = 0;
    int summer = 0;
    cout << "Type a number you want to sum";
    cin >> holder;
    cout << "Write numbers you want to add to the sum, write 0 to return :)";
    summer += holder;
    while(holder != 0){
        cout << "Type a number you want to sum, 0 to return";
        cin >> holder;
        summer += holder;
    }
    return summer;
}

/*
    Det egner seg best med for-loop til den første fordi man på forhånd vet hvor mange ganger man skal itetere gjennom 
    løkken, mens på den andre løkken så vet man ikke hvor mange ganger loops den må gjøre, og det er derfor hensiktsmessig
    å bruke en while-løkke til dette.
*/

double inputDouble(){
    double num = 0;
    cout << "Write a decimal number here: ";
    cin >> num;
    return num;
}

bool validatorConverter(double check){
    return check <= 0;
}

double converter(){
    double current = inputDouble();
    double rate = 8.9;
    if(validatorConverter(current)){
        return current*rate;
    }
    else{
        cout << "Invalid input";
        converter();
    }
}

//For mer nøyaktighet, og at man slipper å caaste (:
