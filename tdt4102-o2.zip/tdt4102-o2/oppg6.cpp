#include "std_lib_facilities.h"
#include "oppg6.h"

vector<int> calculateBalance(double deposit, int interest, int years){
    vector<int> niceonedude;
    double multiplier;
    for (int i = 0; i < years; i++){
        multiplier =  1+(interest/100)^i;
        cout << multiplier;
        niceonedude.push_back(round(deposit*multiplier));
    }
    return niceonedude;
}

void nicePrint(vector<int> monis){
	for (int i = 0; i < monis.size(); i++){
		cout <<"Year" << i << ":" << monis.at(i) << "\n";
	}
}

