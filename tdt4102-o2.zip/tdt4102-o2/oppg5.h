#include "std_lib_facilities.h"
#pragma once

void triangle();