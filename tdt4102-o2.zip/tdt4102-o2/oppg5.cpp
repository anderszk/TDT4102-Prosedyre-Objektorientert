#include "Graph.h"
#include "AnimationWindow.h"
#include "oppg5.h"

void triangle(){
	int w = 800;
	int h = 600;
	Point point1;
	Point point2;
	Point point3;

	AnimationWindow win{100, 100, w, h, "Pythagoras"};
	win.wait_for_close();

    win.draw_triangle(point1, point2, point3, Color::red);
}






