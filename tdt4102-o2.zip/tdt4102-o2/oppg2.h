#include "std_lib_facilities.h"
#pragma once

int sumInput();
int summerCancel();
double inputDouble();
bool validatorConverter(double check);
double converter();