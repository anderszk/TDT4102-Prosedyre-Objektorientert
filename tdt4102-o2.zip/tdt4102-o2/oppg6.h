#include "std_lib_facilities.h"
#pragma once

vector<int> calculateBalance(int deposit, int interest, int years);
void nicePrint(vector<int> monis);