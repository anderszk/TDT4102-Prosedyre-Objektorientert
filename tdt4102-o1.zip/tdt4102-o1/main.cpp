#include "std_lib_facilities.h"

int maxOfTwo(int a, int b){
    if(a > b){
        cout << "A is greater than B \n";
        return a;
    }
    else {
        cout << "B is greater than A \n";
        return b;
    }
}

int fibonacci(int n){
    int a = 0;
    int b = 1;
    int temp = 0;
    for (int i = 0; i < n; i++){
        cout << i << ',' << temp << "\n";
        temp = b;
        b += a;
        a = temp;
    }
    cout << "------\n";
    return temp; //Dårlig algoritme, fuck dere.
}

int squareNumberSum(int n){
    int totalSum = 0;
    for(int i = 0; i < n; i++){
        totalSum += i*i;
        cout << i*i << '\n';
    }
    cout << totalSum;
    return totalSum;
}

void triangle(int n){
    int acc = 1;
    int num = 2;
    cout << "Triangle numbers below " << n << "\n";
    while (acc < n){
        cout << acc << '\n';
        acc += num;
        num += 1;
    }
}

bool isPrime(int n){
    for (int k = 2; k < n; k++){
        if(n% k == 0){
            return false;
        }
    }
    return true;
}

void naivePrimeNumbers(int n){
    for (int number = 2; number < n; number++){
        if (isPrime(number)){
            cout << number << " is a prime number :) \n";
        }
    }
}

//Nei :), returnerer ikke en verdi

int returnGreatestDivisor(int n){
    for(int divisor = n-1; divisor > 0; divisor--){
        if (n%divisor == 0){
            return divisor;
        }
    }
}

int main(){
    //cout << "Oppgave a)\n";
    //cout << maxOfTwo(5, 6) << '\n'; 
    //cout << "Oppgave b)\n";
    //fibonacci(13);
    //squareNumberSum(5);
    //triangle(6);
    //cout << isPrime(9);
    //naivePrimeNumbers(10);
    //cout << returnGreatestDivisor(14);

}

