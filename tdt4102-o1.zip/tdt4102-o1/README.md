# TDT4102-Prosedyre-Objektorientert :computer:

Dette er min repo for ovinger og diverse kodesnutter. Kildekode i src og tekstfiler i "Oving x" <br>
Har brukt VSCode som IDE ;)

<br>

## Innhold:notebook_with_decorative_cover:

##### Øvinger  
- :unlock:Øving 1: **** kan bli funnet [her]()!<br>
- :unlock:Øving 2: **** Kan bli funnet [her]()!<br>
- :unlock:Øving 3: **** Kan bli funnet [her]()!<br>
- :unlock:Øving 4: **** Kan bli funnet [her]()!<br>
- :unlock:Øving 5: *** Kan bli funnet [her]()!<br>
- 🔐:Øving 6: **** Kan bli funnet [her]()!<br>
- 🔐:Øving 7: **** Kan bli funnet [her]()!<br>

##### Prosjekt
Prosjektet for dette emnet er ikke gitt enda.

Prosjektet kan du finne i [dette repoet]()!

